import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'globals.dart' as globals;

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  static const String route = '/Dashboard';

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _currentPageIndex = 0; // Track the currently selected page
  Map<String, dynamic>? _selectedTicket; // Track the currently selected ticket
  bool _isLoading = true; // Track if data is loading
  TextEditingController _messageController = TextEditingController(); // Controller for sending new messages
  TextEditingController _editMessageController = TextEditingController(); // Controller for editing messages
  bool showClosed = false;
  String searchQuery = '';


  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await globals.loadStoredData(context); // Load stored data
    await globals.checkStaffLevel(globals.getUserResponse['id'].toString());
    setState(() {
      _isLoading = false; // Set loading to false once data is loaded
    });
  }

  Future<void> loadTicketData(Map<String, dynamic> ticket) async {
    // Check if ChatLog exists, is a list, and has entries
    if (!ticket.containsKey('ChatLog') || ticket['ChatLog'] == null || ticket['ChatLog'].isEmpty) {
      print("ChatLog is missing or empty, skipping.");
      return;
    }

    List<dynamic> chatLog = ticket['ChatLog'];
    print("ChatLog: $chatLog");

    // Debugging ChatLog and mapping to userIds
    List<String> userIds = [];
    for (var chat in chatLog) {
      if (chat.containsKey('Author')) {
        userIds.add(chat['Author'].toString());
        print("Added Author ID: ${chat['Author']}");
      } else {
        print("Warning: 'Author' field is missing in ChatLog entry: $chat");
      }
    }

    // Check if 'OpenedBy' field exists and add it to userIds
    if (ticket.containsKey('OpenedBy')) {
      userIds.add(ticket['OpenedBy'].toString());
      print("Added OpenedBy ID: ${ticket['OpenedBy']}");
    } else {
      print("Warning: 'OpenedBy' field is missing in the ticket.");
    }

    // Remove duplicates by converting to a Set and back to a List
    userIds = userIds.toSet().toList();
    print("Final unique user IDs: $userIds");

    // Fetch guild members if we have userIds to process
    if (userIds.isNotEmpty) {
      await globals.fetchGuildMembers(userIds);
    } else {
      print("No user IDs to fetch, skipping fetchGuildMembers.");
    }
  }


  Future<void> _sendMessage(String ticketNumber) async {
    String content = _messageController.text;
    if (content is! String || content.isEmpty) return; // Validate input
    final String messageId = DateTime.now().millisecondsSinceEpoch.toString(); // Generate MessageId

    await globals.sendMessage(ticketNumber, content, messageId); // Pass MessageId to the globals function

    setState(() {
      _selectedTicket!['ChatLog'].add({
        'Author': globals.getUserResponse['id'], // Ensure Author is an int
        'Content': content,
        'Deleted': false,
        'Edited': false,
        'MessageId': messageId, // Store the MessageId in the ChatLog
        'Time': DateTime.now().toIso8601String(),
      });
    });
    _messageController.clear();
  }

  Future<List<dynamic>> _fetchTicketsWithMembers() async {
    List<dynamic> tickets = globals.staffLevel != null
        ? await globals.fetchAllTickets()
        : await globals.fetchTicketsByUser(globals.getUserResponse['id'].toString());

    // Extract all user IDs from the tickets
    List<String> userIds = tickets
        .map<String>((ticket) => ticket['OpenedBy'].toString())
        .toSet()
        .toList();

    // Fetch guild members before displaying tickets
    await globals.fetchGuildMembers(userIds);

    return tickets;
  }

  Future<void> _deleteMessage(String ticketNumber, String messageId, Map<String, dynamic> chat) async {
    await globals.deleteMessage(ticketNumber, messageId);
    setState(() {
      chat['Deleted'] = true;
    });
  }

  Future<void> _editMessage(String ticketNumber, dynamic messageId, Map<String, dynamic> chat) async {
    String newContent = _editMessageController.text;
    if (newContent.isEmpty) return; // Validate input
    try {
      await globals.editMessage(ticketNumber, messageId.toString(), newContent);
      setState(() {
        chat['Content'] = newContent;
        chat['Edited'] = true;
      });
    } catch (e) {
      print("Error editing message: $e");
    }
    _editMessageController.clear();
    Navigator.pop(context); // Close the edit dialog
  }

  @override
  Widget build(BuildContext context) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    bool isPortrait = width < height; // Check if the screen is in portrait mode

    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator()) // Show a loading indicator while loading
          : isPortrait ? buildMobileView(context) : buildDesktopView(context),
    );
  }

  Widget buildMobileView(BuildContext context) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    return Center(
      child: Container(
        height: height,
        width: width,
        color: const Color.fromARGB(255, 34, 34, 34),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "CenterLogo.png",
              width: width * 0.6, // Adjusted for mobile view
            ),
            SizedBox(
              height: height * 0.02,
            ),
            Text(
              "Admin Panel",
              style: TextStyle(
                fontFamily: "Anton",
                color: const Color.fromARGB(255, 133, 214, 214),
                fontSize: width * 0.05, // Larger font size for mobile
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildDesktopView(BuildContext context) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    return Center(
      child: Container(
        height: height,
        width: width,
        color: globals.themeUIGrey,
        child: Row(
          children: [
            // Sidebar
            Container(
              color: const Color.fromARGB(255, 19, 22, 27),
              width: width * 0.13,
              child: Column(
                children: [
                  Image.asset(
                    "HeaderLogo.png",
                    height: height * 0.05,
                  ),
                  SizedBox(height: height * 0.05),
                  buildSidebarButton(context, Icons.home, "Home", 0),
                  SizedBox(height: height * 0.05),
                  buildSidebarButton(context, Icons.report_gmailerrorred_outlined, "Tickets", 1),
                  if (globals.staffLevel != null) ...[
                    SizedBox(height: height * 0.05),
                    buildSidebarButton(context, Icons.block_outlined, "Bans", 2),
                    SizedBox(height: height * 0.05),
                    buildSidebarButton(context, Icons.speaker_notes_outlined, "Chat Logs", 3),
                    SizedBox(height: height * 0.05),
                    buildSidebarButton(context, Icons.savings_outlined, "Economy", 4),
                  ],
                ],
              ),
            ),
            // Page Content
            Expanded(
              child: Container(
                color: globals.themeUIGrey,
                child: buildPageContent(_currentPageIndex), // Display the corresponding page
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSidebarButton(BuildContext context, IconData icon, String label, int index) {
    final double width = globals.getWidth(context);

    // Determine if we are on any of the Tickets-related pages
    bool isTicketsRelatedPage = _currentPageIndex == 1 || _currentPageIndex == 5 || _currentPageIndex == 6;

    return Column(
      children: [
        TextButton(
          onPressed: () {
            setState(() {
              _currentPageIndex = index;
              _selectedTicket = null;
            });
          },
          child: Row(
            children: [
              Icon(
                icon,
                size: width * 0.015,
              ),
              SizedBox(width: width * 0.005),
              Text(
                label,
                style: TextStyle(
                  fontFamily: "Anton",
                  color: const Color.fromARGB(255, 133, 214, 214),
                  fontSize: width * 0.015,
                ),
              ),
            ],
          ),
        ),
        if (label == "Tickets" && (index == 1 || isTicketsRelatedPage))
          Padding(
            padding: EdgeInsets.only(left: width * 0.02),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextButton(
                  onPressed: () {
                    setState(() {
                      _currentPageIndex = 1;
                      _selectedTicket = null;
                    });
                  },
                  child: Row(
                    children: [
                      Icon(
                        Icons.inbox,
                        size: width * 0.0125,
                      ),
                      SizedBox(width: width * 0.005),
                      Text(
                        "Open Tickets",
                        style: TextStyle(
                          fontFamily: "Anton",
                          color: const Color.fromARGB(255, 133, 214, 214),
                          fontSize: width * 0.0125,
                        ),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _currentPageIndex = 5;
                      _selectedTicket = null;
                    });
                  },
                  child: Row(
                    children: [
                      Icon(
                        Icons.archive,
                        size: width * 0.0125,
                      ),
                      SizedBox(width: width * 0.005),
                      Text(
                        "Closed Tickets",
                        style: TextStyle(
                          fontFamily: "Anton",
                          color: const Color.fromARGB(255, 133, 214, 214),
                          fontSize: width * 0.0125,
                        ),
                      ),
                    ],
                  ),
                ),
                globals.isStaff
                ?TextButton(
                  onPressed: () {
                    setState(() {
                      _currentPageIndex = 6;
                      _selectedTicket = null;
                    });
                  },
                  child: Row(
                    children: [
                      Icon(
                        Icons.people,
                        size: width * 0.0125,
                      ),
                      SizedBox(width: width * 0.005),
                      Text(
                        "Staff Tickets",
                        style: TextStyle(
                          fontFamily: "Anton",
                          color: const Color.fromARGB(255, 133, 214, 214),
                          fontSize: width * 0.0125,
                        ),
                      ),
                    ],
                  ),
                )
                :const SizedBox(),
              ],
            ),
          ),
      ],
    );
  }



  Widget buildPageContent(int pageIndex) {
    print(_selectedTicket);
    if (_selectedTicket != null) {
      switch (pageIndex) {
        case 1:
          return ticketPage(context, _selectedTicket!); // Open Tickets
        case 5:
          return closedTicketPage(context, _selectedTicket!); // Closed Tickets
        case 6:
          return adminTicketPage(context, _selectedTicket!); // Staff Tickets
        default:
          return homePage(context);
      }
    }

    switch (pageIndex) {
      case 0:
        return homePage(context);
      case 1:
        return ticketsPage(context, 'Open Tickets');
      case 5:
        return closedTicketsPage(context); // Closed Tickets
      case 6:
        return adminTicketsPage(context);
      default:
        return homePage(context);
    }
  }



  TextStyle pageTextStyle() {
    return const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white);
  }

  /////////////////////////////////////////// Non-Admin Pages ///////////////////////////////////////////

  Widget homePage(BuildContext context) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    String userId = globals.getUserResponse['id'];
    String avatarHash = globals.getUserResponse['avatar'];
    String globalName = globals.getUserResponse['global_name'];

    // Construct the avatar URL using Discord's CDN
    String avatarUrl = 'https://cdn.discordapp.com/avatars/$userId/$avatarHash.png?size=1024';

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Circle Avatar with Discord Profile Picture
          CircleAvatar(
            radius: width * 0.1, // Adjust the size as needed
            backgroundImage: NetworkImage(avatarUrl),
            backgroundColor: Colors.transparent,
          ),
          SizedBox(height: height * 0.02),
          // Display the global_name beneath the avatar
          Text(
            globalName,
            style: TextStyle(
              color: globals.themeWhite,
              fontSize: width * 0.05, // Adjust the font size as needed
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: height * 0.05), // Add spacing between name and buttons

          // Row containing the two containers
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Blue Container for Report
              GestureDetector(
                onTap: () {
                  _showSubmitReportDialog(context); // Show the submit report dialog
                },
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: height * 0.02, horizontal: width * 0.04),
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.warning, color: Colors.white, size: width * 0.05),
                      SizedBox(height: height * 0.01),
                      Text(
                        'Survival/DM\nReport',
                        style: TextStyle(color: Colors.white, fontSize: width * 0.03, height: 0.9),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),

              SizedBox(width: width * 0.025), // Add spacing between the containers

              // Purple Container for Discord Report
              GestureDetector(
                onTap: () {
                  _showSubmitDiscordReportDialog(context); // Show the submit Discord report dialog
                },
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: height * 0.02, horizontal: width * 0.04),
                  decoration: BoxDecoration(
                    color: Colors.purple,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.report, color: Colors.white, size: width * 0.05),
                      SizedBox(height: height * 0.01),
                      Text(
                        'Discord\nReport',
                        style: TextStyle(color: Colors.white, fontSize: width * 0.03, height: 0.9),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),

              SizedBox(width: width * 0.025), // Add spacing between the containers

              // Red Container for Appeal
              GestureDetector(
                onTap: () {
                  _showSubmitAppealDialog(context); // Show the submit appeal dialog
                },
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: height * 0.02, horizontal: width * 0.04),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.campaign, color: Colors.white, size: width * 0.05),
                      SizedBox(height: height * 0.01),
                      Text(
                        'Make an\nAppeal',
                        style: TextStyle(color: Colors.white, fontSize: width * 0.03, height: 0.9),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget ticketsPage(BuildContext context, String title) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    final bool isStaffTickets = title == 'Staff Tickets';

    return FutureBuilder<List<dynamic>>(
      future: fetchTicketsAndUsers(isStaffTickets),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error fetching tickets',
              style: TextStyle(color: Colors.red),
            ),
          );
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(
            child: Text(
              'No tickets found',
              style: TextStyle(color: Colors.white),
            ),
          );
        } else {
          List<dynamic> tickets = snapshot.data!;

          // Sorting by ticket number (parsed as integer)
          tickets.sort((a, b) => int.parse(a['ticket_number']).compareTo(int.parse(b['ticket_number'])));

          // Filter out closed tickets if `showClosed` is false (only for Staff Tickets)
          if (isStaffTickets && !showClosed) {
            tickets = tickets.where((ticket) => ticket['Closed'] == false).toList();
          }

          // Apply search filtering if a search query is present
          if (searchQuery.isNotEmpty) {
            tickets = tickets.where((ticket) =>
              ticket['OpenedBy'].toString().contains(searchQuery) ||
              (ticket['SteamId'] != null && ticket['SteamId'].toString().contains(searchQuery))
            ).toList();
          }

          return Column(
            children: [
              // Title and search/filter UI
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontFamily: "Anton",
                        color: const Color.fromARGB(255, 133, 214, 214),
                        fontSize: width * 0.03,
                      ),
                    ),
                    if (isStaffTickets) ...[
                      Spacer(),
                      Checkbox(
                        value: showClosed,
                        onChanged: (bool? value) {
                          setState(() {
                            showClosed = value ?? false;
                          });
                        },
                      ),
                      Text(
                        "Show Closed",
                        style: TextStyle(color: Colors.white),
                      ),
                      SizedBox(width: 10),
                      Container(
                        width: width * 0.3,
                        child: TextField(
                          controller: TextEditingController(text: searchQuery),
                          decoration: InputDecoration(
                            hintText: 'Search by Discord ID or SteamID',
                            border: OutlineInputBorder(),
                            fillColor: Colors.white,
                            filled: true,
                          ),
                          onChanged: (value) {
                            setState(() {
                              searchQuery = value;
                            });
                          },
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              // Ticket List
              Expanded(
                child: ListView.builder(
                  itemCount: tickets.length,
                  itemBuilder: (context, index) {
                    final ticket = tickets[index];
                    final ticketType = ticket['TicketType'] ?? 'Non-Website';
                    final isClosed = ticket['Closed'] ?? false;

                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: MouseRegion(
                        cursor: SystemMouseCursors.click, // Change the cursor to a pointer (hand icon)
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedTicket = ticket; // Set the selected ticket
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 4.0), // Space between items
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 28, 29, 31), // Fill color
                              borderRadius: BorderRadius.circular(15), // Rounded corners
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Ticket ${ticket['ticket_number'] ?? 'Unknown'}',
                                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Ticket Type: $ticketType",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Opened By: ${ticket['OpenedByUsername'] ?? ticket['OpenedBy']}",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  if (isClosed && isStaffTickets) ...[
                                    SizedBox(height: 4),
                                    Text(
                                      "Closed By: ${ticket['ClosedByUsername'] ?? 'Unknown User'}",
                                      style: TextStyle(color: Colors.grey, fontSize: 14),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      "Closed On: " + (ticket['CloseTime'] ?? 'No time provided'),
                                      style: TextStyle(color: Colors.grey, fontSize: 14),
                                    ),
                                  ],
                                  SizedBox(height: 4),
                                  Text(
                                    "Reason: " + (ticket['Reason'] ?? 'No reason provided'),
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  if (isStaffTickets)
                                    Text(
                                    (ticket['ClaimedByUsername'] != null && ticket['ClaimedByUsername'].length > 2)
                                        ? "Claimed by: Staff"
                                        : 'Claimed by: No staff provided',
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        }
      },
    );
  }

  Widget adminTicketsPage(BuildContext context) {
  final double height = globals.getHeight(context);
  final double width = globals.getWidth(context);

  return FutureBuilder<List<dynamic>>(
    future: fetchStaffTicketsAndUsers(), // Fetch staff tickets and users
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Center(
          child: CircularProgressIndicator(),
        );
      } else if (snapshot.hasError) {
        return Center(
          child: Text(
            'Error fetching staff tickets',
            style: TextStyle(color: Colors.red),
          ),
        );
      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
        return Center(
          child: Text(
            'No staff tickets found',
            style: TextStyle(color: Colors.white),
          ),
        );
      } else {
        List<dynamic> tickets = snapshot.data!;

        // Sorting by ticket number (parsed as integer)
        tickets.sort((a, b) => int.parse(a['ticket_number']).compareTo(int.parse(b['ticket_number'])));

        // Apply search filtering if a search query is present
        if (searchQuery.isNotEmpty) {
          tickets = tickets.where((ticket) =>
            ticket['OpenedBy'].toString().contains(searchQuery) ||
            (ticket['SteamId'] != null && ticket['SteamId'].toString().contains(searchQuery))
          ).toList();
        }

        return Column(
          children: [
            // Title and search/filter UI
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Text(
                    "Staff Tickets",
                    style: TextStyle(
                      fontFamily: "Anton",
                      color: const Color.fromARGB(255, 133, 214, 214),
                      fontSize: width * 0.03,
                    ),
                  ),
                  Spacer(),
                  Checkbox(
                    value: showClosed,
                    onChanged: (bool? value) {
                      setState(() {
                        showClosed = value ?? false;
                      });
                    },
                  ),
                  Text(
                    "Show Closed",
                    style: TextStyle(color: Colors.white),
                  ),
                  SizedBox(width: 10),
                  Container(
                    width: width * 0.3,
                    child: TextField(
                      controller: TextEditingController(text: searchQuery),
                      decoration: InputDecoration(
                        hintText: 'Search by Discord ID or SteamID',
                        border: OutlineInputBorder(),
                        fillColor: Colors.white,
                        filled: true,
                      ),
                      onChanged: (value) {
                        setState(() {
                          searchQuery = value;
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),
            // Ticket List
            Expanded(
              child: ListView.builder(
                itemCount: tickets.length,
                itemBuilder: (context, index) {
                  final ticket = tickets[index];
                  final ticketType = ticket['TicketType'] ?? 'Non-Website';
                  final isClosed = ticket['Closed'] ?? false;

                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: MouseRegion(
                      cursor: SystemMouseCursors.click, // Change the cursor to a pointer (hand icon)
                      child: GestureDetector(
                        onTap: () {
                            setState(() {
                              _selectedTicket = ticket; // Set the selected ticket
                            });
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4.0), // Space between items
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 28, 29, 31), // Fill color
                            borderRadius: BorderRadius.circular(15), // Rounded corners
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Ticket ${ticket['ticket_number'] ?? 'Unknown'}',
                                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Ticket Type: $ticketType",
                                  style: TextStyle(color: Colors.grey, fontSize: 14),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Opened By: ${ticket['OpenedByUsername'] ?? ticket['OpenedBy']}",
                                  style: TextStyle(color: Colors.grey, fontSize: 14),
                                ),
                                if (isClosed) ...[
                                  SizedBox(height: 4),
                                  Text(
                                    "Closed By: ${ticket['ClosedByUsername'] ?? 'Unknown User'}",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Closed On: " + (ticket['CloseTime'] ?? 'No time provided'),
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                ],
                                SizedBox(height: 4),
                                Text(
                                  "Reason: " + (ticket['Reason'] ?? 'No reason provided'),
                                  style: TextStyle(color: Colors.grey, fontSize: 14),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Claimed By: ${globals.guildMembers[ticket['Claimed By'].toString()]?['username'] ?? 'No staff provided'}",
                                  style: TextStyle(color: Colors.grey, fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      }
    },
  );
}

  Widget closedTicketsPage(BuildContext context) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    return FutureBuilder<List<dynamic>>(
      future: _fetchTicketsWithMembers(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error fetching tickets',
              style: TextStyle(color: Colors.red),
            ),
          );
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(
            child: Text(
              'No closed tickets found',
              style: TextStyle(color: Colors.white),
            ),
          );
        } else {
          final tickets = snapshot.data!.where((ticket) => ticket['Closed'] == true).toList();

          // Sort tickets by ticket number (as an integer)
          tickets.sort((a, b) => int.parse(a['ticket_number']).compareTo(int.parse(b['ticket_number'])));

          return Column(
            children: [
              Text(
                "Closed Tickets",
                style: TextStyle(
                  fontFamily: "Anton",
                  color: const Color.fromARGB(255, 133, 214, 214),
                  fontSize: width * 0.03,
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: tickets.length,
                  itemBuilder: (context, index) {
                    final ticket = tickets[index];
                    final ticketType = ticket['TicketType'] ?? 'Non-Website';

                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: MouseRegion(
                        cursor: SystemMouseCursors.click, // Change the cursor to a pointer (hand icon)
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => closedTicketPage(context, ticket),
                              ),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 4.0), // Space between items
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 28, 29, 31), // Fill color
                              borderRadius: BorderRadius.circular(15), // Rounded corners
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Ticket ${ticket['ticket_number'] ?? 'Unknown'}',
                                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Ticket Type: $ticketType",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Opened By: ${globals.guildMembers[ticket['OpenedBy'].toString()]?['username'] ?? ticket['OpenedBy']}",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Opened On: " + (ticket["OpenTime"] ?? "No time provided"),
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Closed By: ${globals.guildMembers[ticket['ClosedBy'].toString()]?['username'] ?? 'Unknown User'}",
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Closed On: " + (ticket["CloseTime"] ?? "No time provided"),
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Reason: " + (ticket["Reason"] ?? "No reason provided"),
                                    style: TextStyle(color: Colors.grey, fontSize: 14),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        }
      },
    );
  }




  Widget ticketPage(BuildContext context, Map<String, dynamic> ticket) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Ticket #${ticket['ticket_number']}",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: globals.themeUIGrey,
      ),
      body: FutureBuilder<void>(
        future: loadTicketData(ticket), // Load the ticket data and fetch member info
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading ticket data',
                style: TextStyle(color: Colors.red),
              ),
            );
          } else {
            return Container(
              color: globals.themeUIGrey,
              child: Column(
                children: [
                  // Ticket details container
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: globals.themeUIGrey,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white24),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Reason: " + (ticket["Reason"] ?? "No reason provided"),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: width * 0.01, // Adjusts based on screen width
                          ),
                        ),
                        SizedBox(height: height * 0.01), // Spacer between lines
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Opened By: ${globals.guildMembers[ticket['OpenedBy'].toString()]?['username'] ?? ticket['OpenedBy']} (${ticket['OpenedBy']?.toString() ?? 'No user provided'})",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width * 0.01,
                              ),
                            ),
                            SizedBox(width: width * 0.02),
                            Text(
                              "OpenTime: " + (ticket["OpenTime"] ?? "No time provided"),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width * 0.01,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: height * 0.01), // Spacer between lines
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "SteamId: " + (ticket["SteamId"] ?? "No Steam Id provided"),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width * 0.01,
                              ),
                            ),
                            SizedBox(width: width * 0.02),
                            Text(
                              "Location: " + (ticket["Location"] ?? "No location provided"),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width * 0.01,
                              ),
                            ),
                            SizedBox(width: width * 0.02),
                            Text(
                              "Timestamp: " + (ticket["Timestamp"] ?? "No timestamp provided"),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width * 0.01,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: height * 0.01), // Spacer between lines
                        if (ticket["EvidenceLinks"] != null && ticket["EvidenceLinks"].isNotEmpty) ...[
                          Text(
                            "Evidence Links:",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: width * 0.01,
                            ),
                          ),
                          ...ticket["EvidenceLinks"].map<Widget>((link) {
                            return Padding(
                              padding: const EdgeInsets.only(left: 8.0, top: 2.0),
                              child: GestureDetector(
                                onTap: () {
                                  html.window.open(link, '_blank'); // Open link in a new tab
                                },
                                child: Text(
                                  "$link",
                                  style: TextStyle(
                                      color: Colors.blueAccent,
                                      decoration: TextDecoration.underline,
                                      fontSize: width * 0.01),
                                ),
                              ),
                            );
                          }).toList(),
                        ],
                      ],
                    ),
                  ),
                  SizedBox(height: 10), // Space between the details and chat log

                  // Chat log
                  Expanded(
                    child: ticket['ChatLog'] != null && ticket['ChatLog'].isNotEmpty
                    ?ListView.builder(
                      itemCount: ticket['ChatLog'].length,
                      itemBuilder: (context, index) {
                        final chat = ticket['ChatLog'][index];
                        if (chat['Deleted'] && globals.staffLevel == null) {
                          return SizedBox.shrink(); // Hide deleted messages for non-staff users
                        }
                        final userId = chat['Author'].toString();
                        final member = globals.guildMembers[userId];
                        final avatarUrl = member != null
                            ? 'https://cdn.discordapp.com/avatars/$userId/${member['avatar']}.png?size=64'
                            : null;

                        // Filter messages for non-staff users
                        if (globals.staffLevel == null && chat['Content'].startsWith('.') && userId != globals.getUserResponse['id'].toString()) {
                          return SizedBox.shrink();
                        }

                        return ListTile(
                          leading: avatarUrl != null
                              ? CircleAvatar(
                                  backgroundImage: NetworkImage(avatarUrl),
                                )
                              : CircleAvatar(
                                  backgroundColor: Colors.grey,
                                  child: Icon(Icons.person, color: Colors.white),
                                ),
                          title: Text(
                            '${member != null ? member['username'] : 'Unknown User'} ($userId)',
                            style: TextStyle(color: chat['Deleted'] ? Colors.red : Colors.white),
                          ),
                          subtitle: Text(
                            chat['Content'] ?? '',
                            style: TextStyle(color: Colors.grey),
                          ),
                        );
                      },
                    )
                    :Center(
                      child: Text(
                        'No chat logs available',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                  ),

                  // Message input and send button for open tickets
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _messageController,
                            decoration: InputDecoration(
                              hintText: 'Type a message...',
                              hintStyle: TextStyle(color: Colors.grey),
                              border: OutlineInputBorder(),
                            ),
                            style: TextStyle(color: Colors.white),
                            onSubmitted: (value) {
                              _sendMessage(ticket['ticket_number']);
                            },
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.send, color: globals.logoBlue),
                          onPressed: () {
                            _sendMessage(ticket['ticket_number']);
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }


  Widget closedTicketPage(BuildContext context, Map<String, dynamic> ticket) {
    final double height = globals.getHeight(context);
    final double width = globals.getWidth(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Closed Ticket #${ticket['ticket_number']}", style: TextStyle(color: Colors.white)),
        backgroundColor: globals.themeUIGrey,
      ),
      body: Container(
        color: globals.themeUIGrey,
        child: Column(
          children: [
            // Ticket details container
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: globals.themeUIGrey,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white24),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Reason: " + (ticket["Reason"] ?? "No reason provided"),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: width * 0.01, // Adjusts based on screen width
                    ),
                  ),
                  SizedBox(height: height * 0.01), // Spacer between lines
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Opened By: ${globals.guildMembers[ticket['OpenedBy'].toString()]?['username'] ?? 'Unknown User'} (${ticket['OpenedBy']?.toString() ?? 'No user provided'})",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: width * 0.01,
                        ),
                      ),
                      SizedBox(width: width * 0.02),
                      Text(
                        "OpenTime: " + (ticket["OpenTime"] ?? "No time provided"),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: width * 0.01,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: height * 0.01), // Spacer between lines
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "SteamId: " + (ticket["SteamId"] ?? "No Steam Id provided"),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: width * 0.01,
                        ),
                      ),
                      SizedBox(width: width * 0.02),
                      Text(
                        "Location: " + (ticket["Location"] ?? "No location provided"),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: width * 0.01,
                        ),
                      ),
                      SizedBox(width: width * 0.02),
                      Text(
                        "Timestamp: " + (ticket["Timestamp"] ?? "No timestamp provided"),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: width * 0.01,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: height * 0.01), // Spacer between lines
                  if (ticket["EvidenceLinks"] != null && ticket["EvidenceLinks"].isNotEmpty) ...[
                    Text(
                      "Evidence Links:",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: width * 0.01,
                      ),
                    ),
                    ...ticket["EvidenceLinks"].map<Widget>((link) {
                      return Padding(
                        padding: const EdgeInsets.only(left: 8.0, top: 2.0),
                        child: GestureDetector(
                          onTap: () {
                            html.window.open(link, '_blank'); // Open link in a new tab
                          },
                          child: Text(
                            "$link",
                            style: TextStyle(
                                color: Colors.blueAccent,
                                decoration: TextDecoration.underline,
                                fontSize: width * 0.01),
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                ],
              ),
            ),

            SizedBox(height: 10), // Space between the details and chat log
            // Chat log
            Expanded(
              child: ListView.builder(
                itemCount: ticket['ChatLog'].length,
                itemBuilder: (context, index) {
                  final chat = ticket['ChatLog'][index];
                  final userId = chat['Author'].toString();
                  final member = globals.guildMembers[userId];
                  final avatarUrl = member != null
                      ? 'https://cdn.discordapp.com/avatars/$userId/${member['avatar']}.png?size=64'
                      : null;

                  return ListTile(
                    leading: avatarUrl != null
                        ? CircleAvatar(
                            backgroundImage: NetworkImage(avatarUrl),
                          )
                        : CircleAvatar(
                            backgroundColor: Colors.grey,
                            child: Icon(Icons.person, color: Colors.white),
                          ),
                    title: Text(
                      '${member != null ? member['username'] : 'Unknown User'} ($userId)',
                      style: TextStyle(color: chat['Deleted'] ? Colors.red : Colors.white),
                    ),
                    subtitle: Text(
                      chat['Content'] ?? '',
                      style: TextStyle(color: Colors.grey),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }





  /////////////////////////////////////////// Admin Pages ///////////////////////////////////////////

Widget adminTicketPage(BuildContext context, Map<String, dynamic> ticket) {
  final double height = globals.getHeight(context);
  final double width = globals.getWidth(context);


  return Scaffold(
    appBar: AppBar(
      title: Row(
        children: [
          Text(
            "Admin Ticket #${ticket['ticket_number']}",
            style: TextStyle(color: Colors.white),
          ),
          Spacer(),
          // Claim/Unclaim Button in the center
          if (ticket['Claimed By'] == '' || ticket['Claimed By'] == null || ticket['Claimed By'] == globals.getUserResponse['id'].toString())
            ElevatedButton(
              onPressed: () {
                // Call the appropriate function to claim/unclaim the ticket
                if (ticket['Claimed By'] == '' || ticket['Claimed By'] == null) {
                  globals.claimTicket(ticket['ticket_number']);
                } else {
                  globals.unclaimTicket(ticket['ticket_number']);
                }
                setState(() {});
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: ticket['Claimed By'] == '' ? Colors.green : Colors.orange,
              ),
              child: Text(ticket['Claimed By'] == '' || ticket['Claimed By'] == null ? 'Claim' : 'Unclaim'),
            ),
          SizedBox(width: 20),
          // Close Ticket Button
          ElevatedButton(
            onPressed: () {
              globals.closeTicket(ticket['ticket_number']);
              setState(() {});
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text('Close Ticket'),
          ),
        ],
      ),
      backgroundColor: globals.themeUIGrey,
    ),
    body: FutureBuilder<void>(
      future: loadTicketData(ticket), // Load the ticket data and fetch member info
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error loading ticket data',
              style: TextStyle(color: Colors.red),
            ),
          );
        } else {
          return Container(
            color: globals.themeUIGrey,
            child: Column(
              children: [
                // Display ticket details based on type
                buildTicketDetails(context, ticket),
                SizedBox(height: 10), // Space between the details and chat log

                // Chat log
                Expanded(
                  child: ListView.builder(
                    itemCount: ticket['ChatLog'].length,
                    itemBuilder: (context, index) {
                      final chat = ticket['ChatLog'][index];
                      final userId = chat['Author'].toString();
                      final member = globals.guildMembers[userId];
                      final avatarUrl = member != null
                          ? 'https://cdn.discordapp.com/avatars/$userId/${member['avatar']}.png?size=64'
                          : null;

                      return ListTile(
                        leading: avatarUrl != null
                            ? CircleAvatar(
                                backgroundImage: NetworkImage(avatarUrl),
                              )
                            : CircleAvatar(
                                backgroundColor: Colors.grey,
                                child: Icon(Icons.person, color: Colors.white),
                              ),
                        title: Text(
                          '${member != null ? member['username'] : 'Unknown User'} ($userId)',
                          style: TextStyle(color: chat['Deleted'] ? Colors.red : Colors.white),
                        ),
                        subtitle: Text(
                          chat['Content'] ?? '',
                          style: TextStyle(color: Colors.grey),
                        ),
                        trailing: userId == globals.getUserResponse['id'].toString()
                            ? Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.edit, color: Colors.yellow),
                                    onPressed: () {
                                      _editMessageController.text = chat['Content'];
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          return AlertDialog(
                                            title: Text('Edit Message'),
                                            content: TextField(
                                              controller: _editMessageController,
                                              decoration: InputDecoration(hintText: "Edit your message"),
                                            ),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.pop(context),
                                                child: Text('Cancel'),
                                              ),
                                              TextButton(
                                                onPressed: () {
                                                  _editMessage(ticket['ticket_number'], chat['MessageId'], chat);
                                                },
                                                child: Text('Save'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete, color: Colors.red),
                                    onPressed: () {
                                      _deleteMessage(ticket['ticket_number'], chat['MessageId'], chat);
                                    },
                                  ),
                                ],
                              )
                            : null,
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _messageController,
                          decoration: InputDecoration(
                            hintText: 'Type a message...',
                            hintStyle: TextStyle(color: Colors.grey),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.send, color: globals.logoBlue),
                        onPressed: () {
                          _sendMessage(ticket['ticket_number']);
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
      },
    ),
  );
}

Widget buildTicketDetails(BuildContext context, Map<String, dynamic> ticket) {
  final double height = globals.getHeight(context);
  final double width = globals.getWidth(context);
  final String ticketType = ticket['TicketType'] ?? 'Unknown';

  List<Widget> details = [
    Text(
      "Reason: " + (ticket["Reason"] ?? "No reason provided"),
      style: TextStyle(
        color: Colors.white,
        fontSize: width * 0.01, // Adjusts based on screen width
      ),
    ),
    SizedBox(height: height * 0.01),
    Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Opened By: ${globals.guildMembers[ticket['OpenedBy'].toString()]?['username'] ?? ticket['OpenedBy']} (${ticket['OpenedBy']?.toString() ?? 'No user provided'})",
          style: TextStyle(
            color: Colors.white,
            fontSize: width * 0.01,
          ),
        ),
        SizedBox(width: width * 0.02),
        Text(
          "OpenTime: " + (ticket["OpenTime"] ?? "No time provided"),
          style: TextStyle(
            color: Colors.white,
            fontSize: width * 0.01,
          ),
        ),
      ],
    ),
  ];

  if (ticket['Closed'] == true) {
    details.add(
      SizedBox(height: height * 0.01),
    );
    details.add(
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Closed By: ${globals.guildMembers[ticket['ClosedBy'].toString()]?['username'] ?? 'Unknown User'} (${ticket['ClosedBy']?.toString() ?? 'No user provided'})",
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
          SizedBox(width: width * 0.02),
          Text(
            "Close Time: " + (ticket["CloseTime"] ?? "No time provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
        ],
      ),
    );
  }

  // Add the additional details based on the ticket type as before

  if (ticketType == 'In-Game') {
    details.addAll([
      SizedBox(height: height * 0.01),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "SteamId: " + (ticket["SteamID"] ?? "No Steam Id provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
          SizedBox(width: width * 0.02),
          Text(
            "Location: " + (ticket["Location"] ?? "No location provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
          SizedBox(width: width * 0.02),
          Text(
            "Timestamp: " + (ticket["Timestamp"] ?? "No timestamp provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
        ],
      ),
    ]);
  } else if (ticketType == 'Discord') {
    details.addAll([
      SizedBox(height: height * 0.01),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "SteamId: " + (ticket["SteamID"] ?? "No Steam Id provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
          SizedBox(width: width * 0.02),
          Text(
            "Offender Discord ID: " + (ticket["OffenderDiscord"] ?? "No offender provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
        ],
      ),
    ]);
  } else if (ticketType == 'Appeal') {
    details.addAll([
      SizedBox(height: height * 0.01),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "SteamId: " + (ticket["SteamID"] ?? "No Steam Id provided"),
            style: TextStyle(
              color: Colors.white,
              fontSize: width * 0.01,
            ),
          ),
          if (ticket["Timestamp"] != null && ticket["Timestamp"].isNotEmpty)
            SizedBox(width: width * 0.02),
          if (ticket["Timestamp"] != null && ticket["Timestamp"].isNotEmpty)
            Text(
              "Timestamp: " + (ticket["Timestamp"] ?? "No timestamp provided"),
              style: TextStyle(
                color: Colors.white,
                fontSize: width * 0.01,
              ),
            ),
          if (ticket["Location"] != null && ticket["Location"].isNotEmpty)
            SizedBox(width: width * 0.02),
          if (ticket["Location"] != null && ticket["Location"].isNotEmpty)
            Text(
              "Location: " + (ticket["Location"] ?? "No location provided"),
              style: TextStyle(
                color: Colors.white,
                fontSize: width * 0.01,
              ),
            ),
        ],
      ),
    ]);
  }

  if (ticket["EvidenceLinks"] != null && ticket["EvidenceLinks"].isNotEmpty) {
    details.addAll([
      SizedBox(height: height * 0.01),
      Text(
        "Evidence Links:",
        style: TextStyle(
          color: Colors.white,
          fontSize: width * 0.01,
        ),
      ),
      ...ticket["EvidenceLinks"].map<Widget>((link) {
        return Padding(
          padding: const EdgeInsets.only(left: 8.0, top: 2.0),
          child: GestureDetector(
            onTap: () {
              html.window.open(link, '_blank'); // Open link in a new tab
            },
            child: Text(
              "$link",
              style: TextStyle(
                color: Colors.blueAccent,
                decoration: TextDecoration.underline,
                fontSize: width * 0.01,
              ),
            ),
          ),
        );
      }).toList(),
    ]);
  }

  return Container(
    padding: const EdgeInsets.all(16.0),
    decoration: BoxDecoration(
      color: globals.themeUIGrey,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.white24),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: details,
    ),
  );
}



  Widget bansPage(BuildContext context) {
    return Center(child: Text('Bans Page'));
  }

  Widget chatsPage(BuildContext context) {
    return Center(child: Text('Chats Page'));
  }

  Widget economyPage(BuildContext context) {
    return Center(child: Text('Economy Page'));
  }

  /////////////////////////////////////////// Utility Widgets ///////////////////////////////////////////

  Widget popupModalButton({
    required String text,
    required Color buttonColor,
    required VoidCallback onPress,
    double widthFactor = 0.1, // Adjust the width factor as needed
  }) {
    return GestureDetector(
      onTap: onPress,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        width: MediaQuery.of(context).size.width * widthFactor,
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget popupModalTextLine({
    required String title,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    required BuildContext context,
    bool showError = false,
    int maxLines = 1, // Default is a single-line text field
    int maxLength = 1000, // Default max length is 1000 characters, can be overridden
  }) {
    final double height = MediaQuery.of(context).size.height;
    final double width = MediaQuery.of(context).size.width;

    return StatefulBuilder(
      builder: (BuildContext context, StateSetter setState) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: width * 0.015,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (showError)
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Row(
                      children: [
                        Icon(Icons.error, color: Colors.red, size: 16),
                        SizedBox(width: 4),
                        Text(
                          'Required',
                          style: TextStyle(color: Colors.red, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            SizedBox(height: height * 0.01),
            Row(
              children: [
                Icon(icon, color: Colors.grey),
                SizedBox(width: width * 0.01),
                Expanded(
                  child: TextField(
                    controller: controller,
                    maxLines: maxLines,
                    maxLength: maxLength,
                    onChanged: (value) {
                      setState(() {});
                    },
                    decoration: InputDecoration(
                      hintText: hint,
                      border: OutlineInputBorder(),
                      counterText: '', // Hide the default counter
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  '${controller.text.length}/$maxLength',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            SizedBox(height: height * 0.02),
          ],
        );
      },
    );
  }

  Widget dynamicTextField({
    required TextEditingController controller,
    required VoidCallback onRemove,
    bool isRemovable = true,
    bool showError = false,
    double widthFactor = 0.8, // Adjust this as needed
  }) {
    return Builder(
      builder: (context) {
        final double width = MediaQuery.of(context).size.width * widthFactor;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (isRemovable)
                  IconButton(
                    icon: Icon(Icons.remove_circle, color: Colors.red),
                    onPressed: onRemove,
                  ),
                if (isRemovable) SizedBox(width: width * 0.01),
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: InputDecoration(
                      hintText: 'Enter evidence link',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            if (showError)
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                  children: [
                    Icon(Icons.error, color: Colors.red, size: 16),
                    SizedBox(width: 4),
                    Text(
                      'Required',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ],
                ),
              ),
            SizedBox(height: 10), // Spacing between fields
          ],
        );
      },
    );
  }

  Future<void> _showSubmitReportDialog(BuildContext context) async {
    final TextEditingController reasonController = TextEditingController();
    final TextEditingController steamIdController = TextEditingController();
    final TextEditingController timestampController = TextEditingController();
    final TextEditingController locationController = TextEditingController();
    List<TextEditingController> evidenceControllers = [TextEditingController()];
    List<bool> evidenceErrors = [false];

    bool showReasonError = false;
    bool showSteamIdError = false;
    bool showTimestampError = false;
    bool showLocationError = false;

    void addEvidenceField(StateSetter setState) {
      setState(() {
        if (evidenceControllers.length < 3) {
          evidenceControllers.add(TextEditingController());
          evidenceErrors.add(false);
        }
      });
    }

    void removeEvidenceField(int index, StateSetter setState) {
      setState(() {
        if (evidenceControllers.length > 1) {
          evidenceControllers.removeAt(index);
          evidenceErrors.removeAt(index);
        }
      });
    }

    void validateAndSubmit(StateSetter setState) {
      setState(() {
        showReasonError = reasonController.text.isEmpty;
        showSteamIdError = steamIdController.text.isEmpty;
        showTimestampError = timestampController.text.isEmpty;
        showLocationError = locationController.text.isEmpty;

        for (int i = 0; i < evidenceControllers.length; i++) {
          evidenceErrors[i] = evidenceControllers[i].text.isEmpty;
        }
      });

      if (!showReasonError &&
          !showSteamIdError &&
          !showTimestampError &&
          !showLocationError &&
          evidenceErrors.every((error) => !error)) {
        globals.submitTicket(
          reason: reasonController.text,
          steamId: steamIdController.text,
          evidence: evidenceControllers.map((controller) => controller.text).toList(),
          ticketType: 'inGame',
          timestamp: timestampController.text,
          location: locationController.text,
        );
        Navigator.of(context).pop();
      }
    }

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              title: Center(
                child: Text(
                  'Submit In-Game Report',
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.02,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              content: Container(
                height: MediaQuery.of(context).size.height * 0.6,
                width: MediaQuery.of(context).size.width * 0.35,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      popupModalTextLine(
                        title: "Reason",
                        hint: "Enter the reason",
                        controller: reasonController,
                        icon: Icons.report_problem,
                        showError: showReasonError,
                        context: context,
                        maxLines: 4,
                        maxLength: 400,
                      ),
                      popupModalTextLine(
                        title: "Steam ID",
                        hint: "Enter your Steam ID",
                        controller: steamIdController,
                        icon: Icons.person,
                        showError: showSteamIdError,
                        context: context,
                        maxLength: 17,
                      ),
                      Row(
                        children: [
                          Text(
                            "Evidence Link(s)",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: MediaQuery.of(context).size.width * 0.015,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 8),
                          if (evidenceControllers.length < 3)
                            IconButton(
                              icon: Icon(Icons.add_circle, color: Colors.green),
                              onPressed: () => addEvidenceField(setState),
                            ),
                        ],
                      ),
                      ...List.generate(evidenceControllers.length, (index) {
                        return dynamicTextField(
                          controller: evidenceControllers[index],
                          onRemove: () => removeEvidenceField(index, setState),
                          isRemovable: index != 0,
                          showError: evidenceErrors[index],
                        );
                      }),
                      popupModalTextLine(
                        title: "Timestamp",
                        hint: "Enter the timestamp",
                        controller: timestampController,
                        icon: Icons.access_time,
                        showError: showTimestampError,
                        context: context,
                        maxLength: 12,
                      ),
                      popupModalTextLine(
                        title: "Location",
                        hint: "Enter the location",
                        controller: locationController,
                        icon: Icons.location_on,
                        showError: showLocationError,
                        context: context,
                        maxLength: 50,
                      ),
                    ],
                  ),
                ),
              ),
              actions: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    popupModalButton(
                      text: 'Cancel',
                      buttonColor: Colors.red,
                      onPress: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    popupModalButton(
                      text: 'Submit',
                      buttonColor: Colors.green,
                      onPress: () => validateAndSubmit(setState),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showSubmitDiscordReportDialog(BuildContext context) async {
    final TextEditingController reasonController = TextEditingController();
    final TextEditingController discordIdController = TextEditingController();
    final TextEditingController offenderDiscordIdController = TextEditingController();
    List<TextEditingController> evidenceControllers = [TextEditingController()];
    List<bool> evidenceErrors = [false];

    bool showReasonError = false;
    bool showDiscordIdError = false;
    bool showOffenderDiscordIdError = false;

    void addEvidenceField(StateSetter setState) {
      if (evidenceControllers.length < 3) {
        setState(() {
          evidenceControllers.add(TextEditingController());
          evidenceErrors.add(false);
        });
      }
    }

    void removeEvidenceField(int index, StateSetter setState) {
      if (evidenceControllers.length > 1) {
        setState(() {
          evidenceControllers.removeAt(index);
          evidenceErrors.removeAt(index);
        });
      }
    }

    void validateAndSubmit(StateSetter setState) {
      setState(() {
        showReasonError = reasonController.text.isEmpty;
        showDiscordIdError = discordIdController.text.isEmpty;
        showOffenderDiscordIdError = offenderDiscordIdController.text.isEmpty;

        for (int i = 0; i < evidenceControllers.length; i++) {
          evidenceErrors[i] = evidenceControllers[i].text.isEmpty;
        }
      });

      if (!showReasonError &&
          !showDiscordIdError &&
          !showOffenderDiscordIdError &&
          evidenceErrors.every((error) => !error)) {
        globals.submitTicket(
          reason: reasonController.text,
          steamId: discordIdController.text,
          evidence: evidenceControllers.map((controller) => controller.text).toList(),
          ticketType: 'discord',
          offenderDiscordId: int.parse(offenderDiscordIdController.text), // Send offender Discord ID
        );
        Navigator.of(context).pop();
      }
    }

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              title: Center(
                child: Text(
                  'Submit Discord Report',
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.02,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              content: Container(
                height: MediaQuery.of(context).size.height * 0.4,
                width: MediaQuery.of(context).size.width * 0.3,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      popupModalTextLine(
                        title: "Reason",
                        hint: "Enter the reason",
                        controller: reasonController,
                        icon: Icons.report,
                        showError: showReasonError,
                        context: context,
                        maxLines: 4,
                        maxLength: 400,
                      ),
                      popupModalTextLine(
                        title: "Your Discord ID",
                        hint: "Enter your Discord ID",
                        controller: discordIdController,
                        icon: Icons.person,
                        showError: showDiscordIdError,
                        context: context,
                        maxLength: 19,
                      ),
                      popupModalTextLine(
                        title: "Offender Discord ID", // New Field
                        hint: "Enter Offender's Discord ID",
                        controller: offenderDiscordIdController,
                        icon: Icons.person,
                        showError: showOffenderDiscordIdError, // New error flag
                        context: context,
                        maxLength: 19,
                      ),
                      Row(
                        children: [
                          Text(
                            "Evidence Link(s)",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: MediaQuery.of(context).size.width * 0.015,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 8),
                          if (evidenceControllers.length < 3)
                            IconButton(
                              icon: Icon(Icons.add_circle, color: Colors.green),
                              onPressed: () => addEvidenceField(setState),
                            ),
                        ],
                      ),
                      ...List.generate(evidenceControllers.length, (index) {
                        return dynamicTextField(
                          controller: evidenceControllers[index],
                          onRemove: () => removeEvidenceField(index, setState),
                          isRemovable: index != 0,
                          showError: evidenceErrors[index],
                        );
                      }),
                    ],
                  ),
                ),
              ),
              actions: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    popupModalButton(
                      text: 'Cancel',
                      buttonColor: Colors.red,
                      onPress: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    popupModalButton(
                      text: 'Submit',
                      buttonColor: Colors.green,
                      onPress: () => validateAndSubmit(setState),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }



// Fetch the tickets and user data for the admin/staff tickets page
Future<List<dynamic>> fetchStaffTicketsAndUsers() async {
  List<dynamic> tickets = await globals.fetchAllTickets();

  // Filter out closed tickets if `showClosed` is false
  if (showClosed) {
    tickets = tickets.where((ticket) => ticket['Closed'] == true).toList();
  }else{
    tickets = tickets.where((ticket) => ticket['Closed'] != true).toList();
  }

  // Collect all user IDs to fetch usernames
  Set<String> userIds = {};
  for (var ticket in tickets) {
    userIds.add(ticket['OpenedBy'].toString());
    if (ticket['ClosedBy'] != null) userIds.add(ticket['ClosedBy'].toString());
    if (ticket['Claimed By'] != null) userIds.add(ticket['Claimed By'].toString());
  }

  // Fetch usernames from the API
  await globals.fetchGuildMembers(userIds.toList());

  // Add usernames to the ticket data
  for (var ticket in tickets) {
    ticket['OpenedByUsername'] = globals.guildMembers[ticket['OpenedBy']]?['username'] ?? ticket['OpenedBy'];
    if (ticket['ClosedBy'] != null) {
      ticket['ClosedByUsername'] = globals.guildMembers[ticket['ClosedBy']]?['username'] ?? ticket['ClosedBy'];
    }
    if (ticket['Claimed By'] != null) {
      ticket['ClaimedByUsername'] = globals.guildMembers[ticket['Claimed By']]?['username'] ?? 'No staff provided';
    }
  }

  return tickets;
}

// Update the fetchTicketsAndUsers function to exclude closed tickets from the Open Tickets tab
  Future<List<dynamic>> fetchTicketsAndUsers(bool isStaffTickets) async {
    print("Here");
    List<dynamic> tickets = isStaffTickets 
        ? await globals.fetchAllTickets() 
        : await globals.fetchTicketsByUser(globals.getUserResponse['id'].toString());

    // Filter out closed tickets if we are fetching open tickets
    if (!isStaffTickets) {
      tickets = tickets.where((ticket) => !(ticket['Closed'] ?? false)).toList();
    }

    // Collect all user IDs to fetch usernames
    Set<String> userIds = {};
    for (var ticket in tickets) {
      userIds.add(ticket['OpenedBy'].toString());
      if (ticket['ClosedBy'] != null) userIds.add(ticket['ClosedBy'].toString());
      if (ticket['Claimed By'] != null) userIds.add(ticket['Claimed By'].toString());
    }

    // Fetch usernames from the API
    await globals.fetchGuildMembers(userIds.toList());

    // Add usernames to the ticket data
    for (var ticket in tickets) {
      ticket['OpenedByUsername'] = globals.guildMembers[ticket['OpenedBy']]?['username'] ?? ticket['OpenedBy'];
      if (ticket['ClosedBy'] != null) {
        ticket['ClosedByUsername'] = globals.guildMembers[ticket['ClosedBy']]?['username'] ?? ticket['ClosedBy'];
      }
      if (ticket['Claimed By'] != null) {
        ticket['ClaimedByUsername'] = globals.guildMembers[ticket['Claimed By']]?['username'] ?? 'No staff provided';
      }
    }

    return tickets;
  }


  Future<void> _showSubmitAppealDialog(BuildContext context) async {
    final TextEditingController reasonController = TextEditingController();
    final TextEditingController steamIdController = TextEditingController();
    final TextEditingController timestampController = TextEditingController();
    final TextEditingController locationController = TextEditingController();
    List<TextEditingController> evidenceControllers = [TextEditingController()];
    List<bool> evidenceErrors = [false];

    bool showReasonError = false;
    bool showSteamIdError = false;

    void addEvidenceField(StateSetter setState) {
      if (evidenceControllers.length < 3) {
        setState(() {
          evidenceControllers.add(TextEditingController());
          evidenceErrors.add(false);
        });
      }
    }

    void removeEvidenceField(int index, StateSetter setState) {
      if (evidenceControllers.length > 1) {
        setState(() {
          evidenceControllers.removeAt(index);
          evidenceErrors.removeAt(index);
        });
      }
    }

    void validateAndSubmit(StateSetter setState) {
      setState(() {
        showReasonError = reasonController.text.isEmpty;
        showSteamIdError = steamIdController.text.isEmpty;

        for (int i = 0; i < evidenceControllers.length; i++) {
          evidenceErrors[i] = evidenceControllers[i].text.isEmpty;
        }
      });

      if (!showReasonError && !showSteamIdError && evidenceErrors.every((error) => !error)) {
        globals.submitTicket(
          reason: reasonController.text,
          steamId: steamIdController.text,
          evidence: evidenceControllers.map((controller) => controller.text).toList(),
          ticketType: 'appeal',
          timestamp: timestampController.text.isEmpty ? "" : timestampController.text,
          location: locationController.text.isEmpty ? "" : locationController.text,
        );
        Navigator.of(context).pop();
      }
    }

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              title: Center(
                child: Text(
                  'Submit Appeal',
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.02,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              content: Container(
                height: MediaQuery.of(context).size.height * 0.5,
                width: MediaQuery.of(context).size.width * 0.35,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      popupModalTextLine(
                        title: "Reason",
                        hint: "Enter the reason",
                        controller: reasonController,
                        icon: Icons.report_problem,
                        showError: showReasonError,
                        context: context,
                        maxLines: 4,
                        maxLength: 400,
                      ),
                      popupModalTextLine(
                        title: "Steam ID",
                        hint: "Enter your Steam ID",
                        controller: steamIdController,
                        icon: Icons.person,
                        showError: showSteamIdError,
                        context: context,
                        maxLength: 17,
                      ),
                      Row(
                        children: [
                          Text(
                            "Evidence Link(s)",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: MediaQuery.of(context).size.width * 0.015,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 8),
                          if (evidenceControllers.length < 3)
                            IconButton(
                              icon: Icon(Icons.add_circle, color: Colors.green),
                              onPressed: () => addEvidenceField(setState),
                            ),
                        ],
                      ),
                      ...List.generate(evidenceControllers.length, (index) {
                        return dynamicTextField(
                          controller: evidenceControllers[index],
                          onRemove: () => removeEvidenceField(index, setState),
                          isRemovable: index != 0,
                          showError: evidenceErrors[index],
                        );
                      }),
                      popupModalTextLine(
                        title: "Timestamp (Optional)",
                        hint: "Enter the timestamp",
                        controller: timestampController,
                        icon: Icons.access_time,
                        context: context,
                        maxLength: 12,
                      ),
                      popupModalTextLine(
                        title: "Location (Optional)",
                        hint: "Enter the location",
                        controller: locationController,
                        icon: Icons.location_on,
                        context: context,
                        maxLength: 50,
                      ),
                    ],
                  ),
                ),
              ),
              actions: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    popupModalButton(
                      text: 'Cancel',
                      buttonColor: Colors.red,
                      onPress: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    popupModalButton(
                      text: 'Submit',
                      buttonColor: Colors.green,
                      onPress: () => validateAndSubmit(setState),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}
